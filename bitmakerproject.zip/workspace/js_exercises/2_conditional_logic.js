



// EXERCISE: Who's allowed on the ride?

// Store a rider's age in a variable
var rAge = 25;
// Store the rider's height (in cm) in a variable
var rHeight = 158;
// Write a "compound" if/else statement that checks if the rider meets the minimum requirements and logs a message to the console
// Rider's need to be 150cm tall, and at least 13 years of age

if (rAge < 13) {
    console.log("You are too young!");
} else if (rAge > 13) { 
    console.log("You are old enough.");
} else {
    console.log("Nothing.");
}
